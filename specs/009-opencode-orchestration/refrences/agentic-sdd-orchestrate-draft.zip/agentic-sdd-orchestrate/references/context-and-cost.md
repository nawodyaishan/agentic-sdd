# Reference — Context economy and cost accounting

## Context policy

- Prefer precise source paths, line ranges, revision IDs and relevant artifacts to whole repository/context dumps.
- Use direct grep/glob/read/git/test tools where no second reasoning process is needed.
- Delegate only when a fresh low-cost child can reduce parent context or improve a bounded analysis enough to justify coordination.
- Read limited code windows first, expand only when necessary. Never omit the actual failure signal from a truncated test output.
- Keep original raw output in an appropriately private, accessible location **when feasible**; report the exit status, relevant failure excerpts and recovery reference.
- Compaction must preserve human approvals, selected batch, changed-file status, open findings, and pointers to actual evidence. Summaries are not a new approval ledger.

## Cost/accounting policy

Distinct metrics, if observable:

1. **Primary** input/output/cache tokens and context occupancy.
2. **All agents** tokens, calls, retries, compaction usage and total completion time.
3. Go allowance consumed, actual Console credits/Extra Usage and **cash charged**. These are not interchangeable.
4. 9Router upstream cost, retention and quota: report `unknown` unless verified for the actual route.
5. Engineering outcomes: task correctness, relevant test evidence, human review time and rework.

Never infer guaranteed savings from free endpoint price, a shorter main-context transcript, or another model's optimistic report. If metrics are absent, say `unknown`.
