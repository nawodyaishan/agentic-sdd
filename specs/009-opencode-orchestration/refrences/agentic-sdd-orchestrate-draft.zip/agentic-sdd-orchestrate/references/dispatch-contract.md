# Reference — Scoped subagent dispatch and result contracts

## Dispatch packet

Keep short. Omit fields that are genuinely inapplicable, but never omit scope, authority, evidence expectation or stop conditions for consequential work.

```yaml
# Illustrative structure; not an executable OpenCode API schema.
task_id: <identifier>
parent_request: <one sentence>
mode: assist | delegate | learn
source_revision: <commit/worktree identity or unknown>
existing_authority: <approved batch, direct-fix scope or read-only request>
agent_role: <eligible agent identifier>
model_policy: <effective candidate, provider and any required user decision>
objective: <one bounded result>
inputs: [<exact allowed references>]
allowed_read_scope: [<paths or citations>]
allowed_write_scope: [<explicit paths or none>]
forbidden_effects: [<relevant prohibitions>]
acceptance: [<observable checks>]
verification_owner: <parent | selected worker (focused only)>
privacy_spend_permission: <scope or none>
stop_conditions: [<relevant blockers>]
```

The packet is a delegated **task contract**, not a new source of feature approval or independent privilege. Actual tool permissions and OS containment must be enforced separately.

## Child response

```yaml
# Illustrative response fields, not a claim that the runtime emits YAML.
task_id: <identifier>
status: completed | partial | blocked | failed | needs_input
actual_model: <provider/model#variant or unknown>
work_performed: <summary>
changed_paths: [<real paths; empty for read-only>]
findings: [<short conclusions>]
source_references: [<path:line, commit, or evidence link>]
checks: [<command, exit status, observed result>]
unverified: [<unknown or unsupported claims>]
usage_cost: <reported metrics, allowance, cash cost, or unknown>
questions_for_parent: [<material issues>]
```

## Parent obligations

- Read/verify relevant source and diff rather than accepting the report as the fact source.
- Treat missing evidence as `unknown`, not a passing verification result.
- Do not start a new batch, pay for a fallback, run another reviewer, or publish based solely on this packet.
- Preserve the distinct origin of **parent assessment**, **child claim**, and **deterministic test**.
