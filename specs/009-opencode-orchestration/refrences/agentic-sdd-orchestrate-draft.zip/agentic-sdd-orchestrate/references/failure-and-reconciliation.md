# Reference — Failure, uncertainty, and reconciliation

1. **Provider failure before side effects:** record exact model ID and error class; do not silently escalate into another provider/data policy. Offer next *eligible* candidate only within the human-approved scope. Manual first.
2. **Model response is wrong or tests fail:** debug the engineering issue; this is *not* an automatic provider failure and must not trigger repeated model calls until a correct patch appears.
3. **Provider failure after possible writes:** inspect worktree, in-flight session state, created files and external effects before further action; never replay the same edit blindly. Unknown effects mean `blocked`.
4. **Invalid permissions or unsafe reviewer path:** stop; do not treat “read-only” prose as isolation. Preserve Feature 006 `IR-06-01`.
5. **Uncertain requirements:** child returns `needs_input`; parent reconciles known source facts, asks consequential human questions and preserves the original scope.
6. **Conflicting worker reports:** compare underlying files, errors and tests. State what is contradictory; do not rely on an ensemble vote.
7. **Duplicate/partial delivery:** ensure the parent is working on the exact selected approved batch, not an old handoff or a completed batch repeated after compaction.

**End-state terms:** `completed` means the child delivered its scoped result, **not** that the feature passed independent verification or that the human approved it. `partial`, `failed`, `blocked` and `needs_input` are explicit and must not be compressed to success.
